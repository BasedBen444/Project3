"""
python ex2-mr.py -r hadoop hdfs:///user/clouduser/googlebooks-eng-us-all-2gram-20090715-50-subset.csv --output-dir=hdfs:///user/clouduser/output2 --conf-path=mrjob.conf
"""

from mrjob.job import MRJob

class MyMRJob(MRJob):
    def mapper(self, _, line):
        data=line.split('\t')
        ngram = data[0].strip()
        year = data[1].strip()
        count = data[2].strip()
        pages = data[3].strip()
        books = data[4].strip()
        yield ngram, (int(count),int(books))

    def reducer(self, key, list_of_values):
        totalcount=0.0
        totalbooks=0.0
        for v in list_of_values:
            count=v[0]
            books=v[1]
            totalcount = totalcount+count
            totalbooks = totalbooks+books

        yield key, totalcount/totalbooks

if __name__ == '__main__':
    MyMRJob.run()




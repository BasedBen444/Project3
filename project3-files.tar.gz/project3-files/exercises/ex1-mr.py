"""
python ex1-mr.py -r hadoop hdfs:///user/clouduser/googlebooks-eng-us-all-2gram-20090715-50-subset.csv --output-dir=hdfs:///user/clouduser/output1 --conf-path=mrjob.conf
"""

from mrjob.job import MRJob

class MyMRJob(MRJob):
    def mapper(self, _, line):
        data=line.split('\t')
        ngram = data[0].strip()
        year = data[1].strip()
        count = data[2].strip()
        yield ngram, int(year)

    def reducer(self, key, list_of_values):
        min_year = min(list_of_values)
        if min_year>1994:
            yield key, min_year
		
        
if __name__ == '__main__':
    MyMRJob.run()

